
export const ROUTER_REPORT_KEY = "router";
export const JS_ERROR_REPORT_KEY = "js_error";
export const STATIC_ERROR_REPORT_KEY = "static_error";
export const NETWORK_REPORT_KEY = "network";
export const TRACK_REPORT_KEY = "custom";
export const PERFORMANCE_REPORT_KEY = "performance";
export const BLANK_SCREEN_REPORT_KEY = "blank_screen";

